<?php
/**
 * Plugin Name:         Total Recipe Generator for Gutenberg
 * Author:              SaurabhSharma
 * Author URI:          http://codecanyon.net/user/saurabhsharma
 * Requires at least:   5.8
 * Requires PHP:        7.0
 * Version:             0.5.0
 * Domain Path:         /languages/
 * Description:         A Gutenberg Recipe Block for creating online recipe content with schema microdata, nutrition facts table, and nicely formatted recipe methods.
 * Text Domain:         trg_gt
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Total_Recipe_Generator_Gt' ) ) {
    /**
     * Main Total_Recipe_Generator_Gt Class
     *
     */
    final class Total_Recipe_Generator_Gt {

        private static $instance;

        /**
         * Main Total_Recipe_Generator_Gt Instance
         */
        public static function instance() {

            if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Total_Recipe_Generator_Gt ) ) {

                self::$instance = new Total_Recipe_Generator_Gt;

                self::$instance->trg_gt_includes();

                self::$instance->trg_gt_hooks();

            }
            return self::$instance;
        }

        /**
         * Throw error on object clone
         *
         */
        public function __clone() {
            // Cloning instances of the class is forbidden
            _doing_it_wrong( __FUNCTION__, esc_html__( 'Not allowed.', 'trg_gt' ), '1.0' );
        }

        /**
         * Disable unserializing of the class
         *
         */
        public function __wakeup() {
            // Unserializing instances of the class is forbidden
            _doing_it_wrong( __FUNCTION__, esc_html__( 'Unserializing forbidden.', 'trg_gt' ), '1.0' );
        }

        /**
         * Include files
         */

        public function trg_gt_includes() {
            $plugin_dir = trailingslashit( plugin_dir_path( __FILE__ ) );
            require_once( $plugin_dir . 'includes/lzb/lazy-blocks.php' );
            require_once( $plugin_dir . 'includes/block.php' );
            require_once( $plugin_dir . 'includes/class.settings-api.php' );
            require_once( $plugin_dir . 'includes/settings.php' );
            require_once( $plugin_dir . 'includes/BFI_Thumb.php' );
            require_once( $plugin_dir . 'includes/helper-functions.php' );
        }

        
        /**
         * Include Lazy Blocks Framework
         *
         * https://wordpress.org/plugins/lazy-blocks/
         *
         */

        public function trg_lzb_url( $url ) {
           return trailingslashit( plugin_dir_url( __FILE__ ) ) . 'includes/lzb/';
        }

        
        /**
         * Setup the default hooks and actions
         */
        private function trg_gt_hooks() {

            add_action( 'plugins_loaded', array( self::$instance, 'load_plugin_textdomain' ) );

            add_action( 'enqueue_block_assets', array( self::$instance, 'enqueue_frontend_styles' ), 10 );

            // filter for Frontend output.
            add_filter( 'lazyblock/total-recipe-generator-gt/frontend_callback', array( self::$instance, 'trg_gt_render' ), 10, 2 );

            // filter for Editor output.
            add_filter( 'lazyblock/total-recipe-generator-gt/editor_callback', array( self::$instance, 'trg_gt_render_editor' ), 10, 2 );
            
            // Lazy Blocks Plugin URL
            add_filter( 'lzb/plugin_url', array( self::$instance, 'trg_lzb_url' ) );

            // Custom CSS in head
            add_action( 'wp_head',  array( self::$instance, 'trg_gt_add_global_css' ) );
            add_action( 'wp_head', array( self::$instance, 'trg_gt_add_css_to_front' ) );
            add_action( 'wp_head', array( self::$instance, 'trg_gt_add_fontawesome' ) );
            add_action( 'admin_head', array( self::$instance, 'trg_gt_add_fontawesome' ) );

            // Allow iframe in posts
            add_filter( 'wp_kses_allowed_html', array( self::$instance, 'trg_allow_iframes_in_post' ) );

            // Register REST field for recipe data
            add_action( 'rest_api_init', array( self::$instance, 'trg_register_rest_field' ) );
        }

        
        /**
         * Register REST field for recipe data
         * 
         */
        
        public function trg_register_rest_field() {
            register_rest_field( 'post', 'trg_gt_meta', array(
                'get_callback' => array( self::$instance, 'trg_gt_data' )
            ) );
        }

        
        /**
         * Callback for register REST field
         * 
         */

        public function trg_gt_data() {  
            return get_post_meta( get_the_ID(), 'trg_gt_data', true );
        }

        
        /**
         * Callback render for frontend
         * 
         */

        public function trg_gt_render( $output, $args ) {

            $defaults = array(
                'name_txt' => '',
                'img_lib' => '',
                'summary' => '',
                'prep_time' => '10',
                'cook_time' => '15',
                'perform_time' => '15',
                'total_time' => '0',
                'recipe_yield' => '',
                'serving_size' => '',
                'calories' => '',
                'total_cost' => '',
                'cost_per_serving' => '',
                'cust_meta' => array(),
                'template' => 'recipe',
                'show_title' => 1,
                'recipe_title_tag' => 'h2',
                'title_color' => '',
                'show_date' => '',
                'show_author' => '',
                'author_src' => 'post_author',
                'author_name' => '',
                'author_url' => '',
                'show_image' => 1,
                'imgsize' => 'full',
                'imgwidth' => '',
                'imgheight' => '',
                'imgcrop' => false,
                'imgquality' => 80,
                'show_summary' => 1,
                'summary_color' => '',
                'ib_label_color' => '',
                'ib_value_color' => '',
                'rm_labels' => '',
                'tags_bg' => '',
                'tags_bg_hover' => '',
                'tags_color' => '',
                'tags_color_hover' => '',
                'ing_icon_color' => '',
                'ing_h_color' => '',
                'ing_sub_h_color' => '',
                'list_icon_color' => '',
                'method_icon_color' => '',
                'method_h_color' => '',
                'method_sub_h_color' => '',
                'count_color' => '',
                'recipe_cuisine' => array(),
                'recipe_cuisine_other' => '',
                'recipe_category' => array(),
                'recipe_category_other' => '',
                'recipe_keywords' => '',
                'cooking_method' => '',
                'suitable_for_diet' => array(),
                'suitable_for_diet_other' => '',
                'show_tags' => '',
                'cust_attr' => array(),
                'ing_heading' => esc_html__( 'Ingredients', 'trg_gt' ),
                'ingredients' => array(),
                'method_heading' => esc_html__( 'Method', 'trg_gt' ),
                'enable_numbering' => '',
                'reset_count' => '',
                'show_nutrition' => 1,
                'show_nutrition_only' => '',
                'methods' => array(),
                'display_style' => 'std',
                'show_dv' => '',
                'serving_per_cont' => 0,
                'total_fat' => 0,
                'saturated_fat' => 0,
                'trans_fat' => 0,
                'polyunsat_fat' => 0,
                'monounsat_fat' => 0,
                'cholesterol' => 0,
                'sodium' => 0,
                'carbohydrate' => 0,
                'fiber' => 0,
                'sugar' => 0,
                'added_sugar' => 0,
                'sugar_alcohal' => 0,
                'protein' => 0,
                'vitamin_d' => 0,
                'calcium' => 0,
                'iron' => 0,
                'potassium' => 0,
                'vitamin_a' => 0,
                'vitamin_c' => 0,
                'vitamin_e' => 0,
                'vitamin_k' => 0,
                'vitamin_b1' => 0,
                'vitamin_b2' => 0,
                'vitamin_b3' => 0,
                'vitamin_b6' => 0,
                'folate' => 0,
                'vitamin_b12' => 0,
                'biotin' => 0,
                'choline' => 0,
                'vitamin_b5' => 0,
                'phosphorus' => 0,
                'iodine' => 0,
                'magnesium' => 0,
                'zinc' => 0,
                'selenium' => 0,
                'copper' => 0,
                'manganese' => 0,
                'chromium' => 0,
                'molybdenum' => 0,
                'chloride' => 0,
                'custom_nutrients' => array(),
                'extra_notes' => esc_html__( '* The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.', 'trg_gt' ),
                'json_ld' => '',
                'website_schema' => '',
                'rating_src' => '',
                'vid_name' => '',
                'vid_url' => '',
                'vid_thumb_url' => '',
                'vid_description' => '',
                'vid_date' => '',
                'vid_duration' => ''
            );

            $args = wp_parse_args( $args, $defaults );

            extract( $args );

            static $i = 0;
            static $block_data = array();

            // Global settings
            $general = get_option( 'trg_general' );
            $social = get_option( 'trg_social' );
            $labels = get_option( 'trg_labels' );

            ob_start();

                $template_path = apply_filters( 'trg_template_path', '/includes/trg_templates/' );

                if ( locate_template( $template_path . 'recipe.php' ) ) {
                    require( get_stylesheet_directory() . $template_path . 'recipe.php' );
                }
                else {
                    require( dirname( __FILE__ ) . $template_path . 'recipe.php' );
                }

            return ob_get_clean();

        }

        /**
         * Callback render for editor mode
         * 
         */        

        public function trg_gt_render_editor( $output, $args ) {

            ob_start();

            $args['context'] = 'editor';
            echo $this->trg_gt_render( $output, $args );

            return ob_get_clean();

        }


        /**
         * Load Plugin Text Domain
         *
         */
        public function load_plugin_textdomain() {

            $lang_dir = apply_filters( 'trg_gt_lang_dir', trailingslashit( plugin_dir_path(__FILE__) . 'languages' ) );

            // Native WordPress plugin locale filter
            $locale = apply_filters( 'plugin_locale', get_locale(), 'trg_gt' );
            $mofile = sprintf( '%1$s-%2$s.mo', 'trg_gt', $locale );

            // Paths to current locale file
            $mofile_local = $lang_dir . $mofile;

            if ( file_exists( $mofile_local ) ) {
                // wp-content/plugins/total-recipe-generator-gt/languages/ folder
                load_textdomain( 'trg_gt', $mofile_local );
            }
            else {
                // Load default language files
                load_plugin_textdomain( 'trg_gt', false, $lang_dir );
            }

            return false;
        }


        /**
         * Load frontend styles
         *
         */
        public function enqueue_frontend_styles() {

            wp_enqueue_style( 'trg-gt-plugin-css', plugin_dir_url( __FILE__ ) . 'assets/css/trg.frontend.css', array(), null );

            // RTL CSS
            if ( is_rtl() ) {
                wp_enqueue_style( 'trg-gt-plugin-rtl', plugin_dir_url( __FILE__ ) . 'assets/css/trg.frontend.rtl.css', array(), null );
            }

            // JavaScript files
           wp_enqueue_script( 'trg-gt-plugin-functions', plugin_dir_url( __FILE__ ) . 'assets/js/trg.frontend.js', array( 'jquery' ), '', true );

            // Localization
            $social = get_option( 'trg_social' );
            $trg_localization = array(
                'plugins_url' => plugins_url() . '/total-recipe-generator-gt',
                'prnt_header' => isset( $social['prnt_header'] ) ? $social['prnt_header'] : '',
                'prnt_footer' => isset( $social['prnt_footer'] ) ?$social['prnt_footer'] : '',
            );
            wp_localize_script( 'trg-gt-plugin-functions', 'trg_localize', $trg_localization );

        }


        /**
         * Global CSS from plugin settings
         *
         */
        function trg_gt_add_global_css() {
            $colors = get_option( 'trg_display' );
            $css = '';
            // Icon color
            if ( isset( $colors ) && ! empty( $colors ) ) {
                if ( isset( $colors['icon_color'] ) && '' != $colors['icon_color'] ) {
                    $css .= '.recipe-heading > .trg-icon,.method-heading > .trg-icon{color:' . $colors['icon_color'] . ' ;}';
                }

                if ( $colors['heading_color'] && '' != $colors['heading_color'] ) {
                    $css .= '.trg .recipe-heading{color:' . $colors['heading_color'] . ';}';
                }

                if ( isset( $colors['label_color'] ) && '' != $colors['label_color'] ) {
                    $css .= '.info-board>li .ib-label,.cuisine-meta .cm-label{color:' . $colors['label_color'] . ';}';
                }

                if ( isset( $colors['highlights'] ) && '' != $colors['highlights'] ) {
                    $css .= '.info-board>li .ib-value{color:' . $colors['highlights'] . ';}';
                }

                if ( isset( $colors['tick_color'] ) && '' != $colors['tick_color'] ) {
                    $css .= '.ing-list>li .trg-icon{color:' . $colors['tick_color'] . ';}';
                }

                if ( isset( $colors['count_color'] ) && '' != $colors['count_color'] ) {
                    $css .= '.step-num{color:' . $colors['count_color'] . ';}';
                }

                // Tags links CSS
                if ( isset( $colors['tags_bg'] ) && ( '' != $colors['tags_bg'] || '' != $colors['tags_color'] ) ) {
                    $css .= '.cuisine-meta .cm-value:not(.link-enabled),.cuisine-meta .cm-value a{';
                    $css .= ( '' != $colors['tags_bg'] ) ? 'background-color:' . $colors['tags_bg'] . ';' : '';
                    $css .= ( '' != $colors['tags_color'] ) ? 'color:' . $colors['tags_color'] . ';' : '';
                    $css .= 'box-shadow:none;}';
                }

                // Tags links hover CSS
                if ( isset( $colors['tags_bg_hover'] ) && ( '' != $colors['tags_bg_hover'] || '' != $colors['tags_color_hover'] ) ) {
                    $css .= '.cuisine-meta .cm-value a:hover,.cuisine-meta .cm-value a:active{';
                    $css .= ( '' != $colors['tags_bg_hover'] ) ? 'background-color:' . $colors['tags_bg_hover'] . ';' : '';
                    $css .= ( '' != $colors['tags_color_hover'] ) ? 'color:' . $colors['tags_color_hover'] . ';' : '';
                    $css .= '}';
                }

                // Social links CSS
                if ( isset( $colors['social_bg'] ) && ( '' != $colors['social_bg'] || '' != $colors['social_color'] ) ) {
                    $css .= '.trg-sharing li a{';
                    $css .= ( '' != $colors['social_bg'] ) ? 'background-color:' . $colors['social_bg'] . ';' : '';
                    $css .= ( '' != $colors['social_color'] ) ? 'color:' . $colors['social_color'] . ';' : '';
                    $css .= 'box-shadow:none;}';
                }

                // Social links hover CSS
                if ( isset( $colors['social_bg_hover'] ) && ( '' != $colors['social_bg_hover'] || '' != $colors['social_color_hover'] ) ) {
                    $css .= '.trg-sharing li a:hover{';
                    $css .= ( '' != $colors['social_bg_hover'] ) ? 'background-color:' . $colors['social_bg_hover'] . ';' : '';
                    $css .= ( '' != $colors['social_color_hover'] ) ? 'color:' . $colors['social_color_hover'] . ';' : '';
                    $css .= '}';
                }
            }
            if ( $css ) {
                echo '<style id="trg_gt_global_css" type="text/css"> ' . $css . '</style>';
            }
        }

        
        /**
         * Allow iframe tag in wp_kses_allowed_html
         * 
         */
        
        function trg_allow_iframes_in_post( $allowedtags ) {
            if ( ! current_user_can( 'publish_posts' ) ) return $allowedtags;
            // Allow iframes and the following attributes
            $allowedtags['iframe'] = array(
                'align' => true,
                'width' => true,
                'height' => true,
                'frameborder' => true,
                'name' => true,
                'src' => true,
                'id' => true,
                'class' => true,
                'style' => true,
                'scrolling' => true,
                'marginwidth' => true,
                'marginheight' => true,
            );
            return $allowedtags;
        }

        public function trg_gt_parse_blocks( $blocks ) {
            if ( isset( $blocks ) && is_array( $blocks ) ) :
                foreach ( $blocks as $block ) {

                    if ( isset( $block['blockName'] ) && 'lazyblock/total-recipe-generator-gt' === $block['blockName'] ) {                     
                        
                        if ( isset( $block['attrs']['title_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .recipe-title{color:' . $block['attrs']['title_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['summary_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .recipe-summary{color:' . $block['attrs']['summary_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['ib_label_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .info-board > li .ib-label{color:' . $block['attrs']['ib_label_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['ib_value_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .info-board > li .ib-value{color:' . $block['attrs']['ib_value_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['rm_labels'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .cuisine-meta .cm-label{color:' . $block['attrs']['rm_labels'] . ';}';
                        }

                        if ( isset( $block['attrs']['tags_color'] ) || isset( $block['attrs']['tags_bg'] ) ) {
                            printf( '.%1$s .cuisine-meta .cm-value:not(.link-enabled),.%1$s .cuisine-meta .cm-value a{%2$s%3$s}',
                                $block['attrs']['blockUniqueClass'],
                                isset( $block['attrs']['tags_color'] ) ? 'color: ' . $block['attrs']['tags_color'] . ';' : '',
                                isset( $block['attrs']['tags_bg'] ) ? 'background-color: ' . $block['attrs']['tags_bg'] . ';' : ''
                            );
                        }

                        if ( isset( $block['attrs']['tags_color_hover'] ) || isset( $block['attrs']['tags_bg_hover'] ) ) {
                            printf( '.%1$s .cuisine-meta .cm-value a:hover{%2$s%3$s}',
                                $block['attrs']['blockUniqueClass'],
                                isset( $block['attrs']['tags_color_hover'] ) ? 'color: ' . $block['attrs']['tags_color_hover'] . ';' : '',
                                isset( $block['attrs']['tags_bg_hover'] ) ? 'background-color: ' . $block['attrs']['tags_bg_hover'] . ';' : ''
                            );
                        }

                        if ( isset( $block['attrs']['ing_icon_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .ing-title .trg-icon{color:' . $block['attrs']['ing_icon_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['ing_h_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .ing-title{color:' . $block['attrs']['ing_h_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['ing_sub_h_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .list-subhead{color:' . $block['attrs']['ing_sub_h_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['list_icon_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .ing-list .trg-icon{color:' . $block['attrs']['list_icon_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['method_icon_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .ins-title .trg-icon{color:' . $block['attrs']['method_icon_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['method_h_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .ins-title{color:' . $block['attrs']['method_h_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['method_sub_h_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .inst-subhead{color:' . $block['attrs']['method_sub_h_color'] . ';}';
                        }

                        if ( isset( $block['attrs']['count_color'] ) ) {
                            echo '.' . $block['attrs']['blockUniqueClass'] . ' .step-num{color:' . $block['attrs']['count_color'] . ';}';
                        }

                    } // if trg block  
                    else {
                        // Check for nested blocks
                        if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                            $this->trg_gt_parse_blocks( $block['innerBlocks'] );
                        }
                    }
                } // foreach
            endif;
        }


        /**
         * Add per block CSS to thr front
         *
         */
        
        public function trg_gt_add_css_to_front() {
            global $post;

            if ( isset( $post ) && isset( $post->post_content ) ) :
                
                $blocks = parse_blocks( $post->post_content );
                 
                if ( isset( $blocks ) && is_array( $blocks ) ) :
                    // Frontend styles
                    echo '<style type="text/css" id="trg-gt-frontend-styles">';
                        $this->trg_gt_parse_blocks( $blocks );                
                    echo '</style>';
                endif; // $blocks
            
            endif; // $post
        }


        /**
         * Load fontawesome font file
         *
         */        

        function trg_gt_add_fontawesome() {
            echo '<script src="https://kit.fontawesome.com/0a28ce9c7b.js" crossorigin="anonymous"></script>';
        }

    }
} // If not class exists

/**
 * Generate Instance
 */
function trg_gt() {
    return Total_Recipe_Generator_Gt::instance();
}

trg_gt();        