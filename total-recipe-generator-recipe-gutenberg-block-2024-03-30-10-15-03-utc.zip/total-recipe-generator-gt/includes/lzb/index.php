<?php
/**
 * Silence is golden
 *
 * @package lazyblocks
 */
