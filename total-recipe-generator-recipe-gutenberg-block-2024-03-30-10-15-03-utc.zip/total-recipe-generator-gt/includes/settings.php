<?php
/**
 * TRG Settings Page in Admin
 *
 * Uses TRG_Settings_API Class
 */

if ( ! class_exists( 'Generate_TRG_Settings' ) ) :

	class Generate_TRG_Settings {

		private $settings_api;

		function __construct() {
			$this->settings_api = new TRG_Settings_API;

			add_action( 'admin_init', array($this, 'admin_init') );
			add_action( 'admin_menu', array($this, 'admin_menu') );
		}

		function admin_init() {

			//set the settings
			$this->settings_api->set_sections( $this->get_settings_sections() );
			$this->settings_api->set_fields( $this->get_settings_fields() );

			//initialize settings
			$this->settings_api->admin_init();
		}

		function admin_menu() {
			add_options_page( 'Total Recipe Generator Settings', 'Total Recipe Generator', 'manage_options', 'trg_settings', array($this, 'plugin_page') );
		}

		function get_settings_sections() {
			$sections = array(
				array(
					'id' => 'trg_general',
					'title' => esc_attr__( 'General', 'trg_gt' )
				),
				array(
					'id' => 'trg_display',
					'title' => esc_attr__( 'Display', 'trg_gt' )
				),
				array(
					'id' => 'trg_social',
					'title' => esc_attr__( 'Social', 'trg_gt' )
				)
			);
			return $sections;
		}

		/**
		 * Returns all the settings fields
		 *
		 * @return array settings fields
		 */
		function get_settings_fields() {
			$settings_fields = array(
				'trg_general' => array(

					array(
						'name'              => 'block_preview',
						'label'             => esc_attr__( 'Show block preview in editor', 'trg_gt' ),
						'desc'              => esc_attr__( 'Choose when to show block preview in the editor.', 'trg_gt' ),
						'type'              => 'select',
						'default'           => 'selected',
						'options'			=> array(
							'always'		=> __( 'Always', 'trg_gt' ),
							'selected'	 	=> __( 'Within \'selected\' block only', 'trg_gt' ),
							'unselected'	=> __( 'Within \'unselected\' block only', 'trg_gt' ),
							'never'	 		=> __( 'Never', 'trg_gt' )
						)
					),

					array(
						'name'              => 'ad_spot_1',
						'label'             => esc_attr__( 'Global ad spot 1', 'trg_gt' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown above ingredients section. Individual recipe post can override this setting', 'trg_gt' ),
						'type'              => 'textarea',
						'default'           => ''
					),

					array(
						'name'              => 'ad_spot_2',
						'label'             => esc_attr__( 'Global ad spot 2', 'trg_gt' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown above methods section. Individual recipe post can override this setting', 'trg_gt' ),
						'type'              => 'textarea',
						'default'           => ''
					),

					array(
						'name'              => 'ad_spot_3',
						'label'             => esc_attr__( 'Global ad spot 3', 'trg_gt' ),
						'desc'              => esc_attr__( 'Global ad spot to be shown after nutrition table. Individual recipe post can override this setting', 'trg_gt' ),
						'type'              => 'textarea',
						'default'           => ''
					)
				),
				'trg_display' => array(

					array(
						'name'              => 'prep_time_label',
						'label'             => esc_attr__( 'Prep Time Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for preparation time', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Prep Time', 'trg_gt' )
					),

					array(
						'name'              => 'cook_time_label',
						'label'             => esc_attr__( 'Cook Time Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for cooking time', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Cook Time', 'trg_gt' )
					),

					array(
						'name'              => 'perform_time_label',
						'label'             => esc_attr__( 'Perform Time Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for perform time', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Perform Time', 'trg_gt' )
					),

					array(
						'name'              => 'total_time_label',
						'label'             => esc_attr__( 'Total Time Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for total time', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Total Time', 'trg_gt' )
					),

					array(
						'name'              => 'yield_label',
						'label'             => esc_attr__( 'Recipe Yield Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for recipe Yield', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Yield', 'trg_gt' )
					),

					array(
						'name'              => 'serving_size_label',
						'label'             => esc_attr__( 'Serving Size Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for serving size', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Serving Size', 'trg_gt' )
					),

					array(
						'name'              => 'energy_label',
						'label'             => esc_attr__( 'Energy Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Energy', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Energy', 'trg_gt' )
					),

					array(
						'name'              => 'total_cost_label',
						'label'             => esc_attr__( 'Total Cost Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Total Cost', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Total Cost', 'trg_gt' )
					),

					array(
						'name'              => 'cost_per_serving_label',
						'label'             => esc_attr__( 'Cost per Serving Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Cost per Serving', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Cost per Serving', 'trg_gt' )
					),

					array(
						'name'              => 'cuisine_label',
						'label'             => esc_attr__( 'Cuisine Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Cuisine', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Cuisine', 'trg_gt' )
					),

					array(
						'name'              => 'course_label',
						'label'             => esc_attr__( 'Course Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Course', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Course', 'trg_gt' )
					),

					array(
						'name'              => 'cooking_method_label',
						'label'             => esc_attr__( 'Cuisine Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Cooking Method', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Cooking Method', 'trg_gt' )
					),

					array(
						'name'              => 'sfd_label',
						'label'             => esc_attr__( 'Suitable for Diet Label', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a label for Suitable for Diet', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Suitable for Diet', 'trg_gt' )
					),

					array(
						'name'              => 'ing_heading',
						'label'             => esc_attr__( 'Ingredients heading', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a text for ingredients heading', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Ingredients', 'trg_gt' )
					),

					array(
						'name'              => 'method_heading',
						'label'             => esc_attr__( 'Method heading', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a text for method heading', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Method', 'trg_gt' )
					),

					array(
						'name'              => 'nutri_heading',
						'label'             => esc_attr__( 'Nutrition Facts heading', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a text for Nutrition Facts heading', 'trg_gt' ),
						'type'              => 'text',
						'default'           => __( 'Nutrition Facts', 'trg_gt' )
					),

					array(
						'name'    => 'icon_color',
						'label'   => esc_attr__( 'Icons Color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a color for heading icons', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'heading_color',
						'label'   => esc_attr__( 'Heading Color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a color for headings', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_bg',
						'label'   => esc_attr__( 'Tag links background', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a background color for tag links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_color',
						'label'   => esc_attr__( 'Tag links foreground', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a foreground text color for tag links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_bg_hover',
						'label'   => esc_attr__( 'Tag links background hover', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a hover background color for tag links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tags_color_hover',
						'label'   => esc_attr__( 'Tag links hover color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a hover color for tag links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'label_color',
						'label'   => esc_attr__( 'Text labels color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a color for text labels in recipe meta', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'highlights',
						'label'   => esc_attr__( 'Text highlights color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a highlight color for text in recipe meta', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'count_color',
						'label'   => esc_attr__( 'Color for number count', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a color for number count in recipe method', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'tick_color',
						'label'   => esc_attr__( 'Ingredients tick color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a color for tick icon in ingredients section', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'social_color',
						'label'   => esc_attr__( 'Social links color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a foreground color for Social links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'social_bg',
						'label'   => esc_attr__( 'Social links background', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a background color for Social links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'social_color_hover',
						'label'   => esc_attr__( 'Social links hover color', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a hover color for Social links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'    => 'social_bg_hover',
						'label'   => esc_attr__( 'Social links background hover', 'trg_gt' ),
						'desc'    => esc_attr__( 'Choose a hover background color for Social links', 'trg_gt' ),
						'type'    => 'color'
					),

					array(
						'name'              => 'tax_optional',
						'label'             => esc_attr__( 'Taxonomy for meta links', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a taxonomy for meta links. E.g. product_cat, or my_taxonomy. If provided, the tag recipe meta items will be linked to this custom taxonomy archive.', 'trg_gt' ),
						'type'              => 'text',
						'default'           => ''
					),
				),

				'trg_social' => array(
					array(
						'name'              => 'social_heading',
						'label'             => esc_attr__( 'Social sharing heading', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a heading for social sharing buttons', 'trg_gt' ),
						'type'              => 'text',
						'default'           => ''
					),

					array(
						'name'              => 'social_buttons',
						'label'             => esc_attr__( 'Social Sharing buttons', 'trg_gt' ),
						'desc'              => esc_attr__( 'Select social share buttons to show at the end of recipe', 'trg_gt' ),
						'type'              => 'select_multiple',
						'default'           => '',
						'options'			=> array(
							'twitter'		=> __( 'Twitter', 'trg_gt' ),
							'facebook'	 	=> __( 'Facebook', 'trg_gt' ),
							'whatsapp'		=> __( 'WhatsApp', 'trg_gt' ),
							'linkedin'	 	=> __( 'LinkedIn', 'trg_gt' ),
							'pinterest'	 	=> __( 'Pinterest', 'trg_gt' ),
							'vkontakte'	 	=> __( 'VKOntakte', 'trg_gt' ),
							'threads'	 	=> __( 'Threads', 'trg_gt' ),
							'email'	 		=> __( 'Email', 'trg_gt' ),
							'print'	 		=> __( 'Print', 'trg_gt' ),
							'reddit'	 	=> __( 'Reddit', 'trg_gt' )
						)
					),

					array(
						'name'              => 'social_pos',
						'label'             => esc_attr__( 'Social Buttons Placement', 'trg_gt' ),
						'desc'              => esc_attr__( 'Choose placement area for social buttons.', 'trg_gt' ),
						'type'              => 'select',
						'default'           => '5',
						'options'			=> array(
							'1'		=> __( 'Before Recipe Title', 'trg_gt' ),
							'2'	 	=> __( 'Before Recipe Image', 'trg_gt' ),
							'3'		=> __( 'After Recipe Image', 'trg_gt' ),
							'4'		=> __( 'Before Nutrition Facts', 'trg_gt' ),
							'5'		=> __( 'After Nutrition Facts', 'trg_gt' )
						)
					),

					array(
						'name'  => 'social_sticky',
						'label' => esc_attr__( 'Sticky Social Buttons', 'trg_gt' ),
						'desc'  => esc_attr__( 'Make social buttons sticky on mobile', 'trg_gt' ),
						'type'  => 'checkbox'
					),

					array(
						'name'              => 'prnt_header',
						'label'             => esc_attr__( 'Print Header Text', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a header text that shall appear on top of recipe pdf/print.', 'trg_gt' ),
						'type'              => 'textarea',
						'default'           => ''
					),

					array(
						'name'              => 'prnt_footer',
						'label'             => esc_attr__( 'Print footer Text', 'trg_gt' ),
						'desc'              => esc_attr__( 'Provide a footer text that shall appear at bottom of recipe pdf/print.', 'trg_gt' ),
						'type'              => 'textarea',
						'default'           => ''
					)
				)
			);

			return $settings_fields;
		}

		function plugin_page() {
			echo '<div class="wrap">';
			echo '<h1>' . esc_attr__( 'Total Recipe Generator Settings', 'trg_gt' ) . '</h1>';
			$this->settings_api->show_navigation();
			$this->settings_api->show_forms();

			echo '</div>';
		}

		/**
		 * Get all the pages
		 *
		 * @return array page names with key value pairs
		 */
		function get_pages() {
			$pages = get_pages();
			$pages_options = array();
			if ( $pages ) {
				foreach ($pages as $page) {
					$pages_options[$page->ID] = $page->post_title;
				}
			}

			return $pages_options;
		}
	}

	$generate_trg_settings = new Generate_TRG_Settings();

endif;