chrome.cookies.getAll({domain: ".rankytools.com"}, (cookies) => {
    codecookie = ""
    cookies.forEach(function(cookie){
        
        
    codecookie = codecookie+cookie.name+"="+cookie.value+";"
    
    
    })
    
    fetch("https://members.rankytools.com/member", {
      "headers": {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        
        "cookie": codecookie
    },
      "body": null,
      "method": "GET"
    }).then((es) => {
        if (es.ok) {
        return es.text();
        }
        })
        .then((rj) => {
    console.log(rj);
    
     var parser = new DOMParser();
        var htmlDoc = parser.parseFromString(rj, 'text/html');
        urloftool = htmlDoc.getElementById("member-resources");
        if(urloftool!=null){
        
        style = document.createElement("style");
        style.innerHTML = `
        img {
            max-height: 780px;
            max-width: 120px;
        }
        li[id^='resource-link-folder-'][id$='-wrapper'] {
            border: 1px solid #e0e0e0;
            width: 180px;
            margin: 10px;
            float: left;
        }`
        document.querySelector("head").appendChild(style);
    var li = document.createElement("div");  
        li.innerHTML = ` 
      `+urloftool.innerHTML;
    
    
        document.getElementById("member-resources").appendChild(li);  
    
    
    
    
       }else{
    
        var li = document.createElement("div");  
        li.innerHTML = `

        <p><span style="font-size:18px;">Start amazon, eBay, walmart or dropshipping product research & product hunting for private label, wholesale research using famous in-demand tools in the market.</span></p>
							
        
        <hr>

        <center> 
        <a href="https://members.rankytools.com/member" target="_blank"><img alt=" My AMZ Tools Members Area" src="../icons/login.png"> </a>
         
        </center>
        
        
        
        <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" rel="stylesheet"><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" rel="stylesheet">
        <style type="text/css">.heading {
                                            font-family: 'Fjalla One', sans-serif;
                                            color: #331818;
                                            margin: 1em auto;
                                        }
                                        
                                        #response_message .bg-success,
                                        .bg-danger {
                                            background: black !important;
                                            color: white !important;
                                        }
                                        
                                        .btn btn-primary {
                                            color: white !important;
                                            font-weight: 700 !important;
                                        }
        </style>
        <style type="text/css">body {
                                            background: transparent;
                                        }
                                        
                                        .heading {
                                            font-family: 'Fjalla One', sans-serif;
                                            color: #331818;
                                            margin: 1em auto;
                                        }
                                        
                                        #response_message .btn {
                                            background: white !important;
                                            color: black !important;
                                            font-weight: 700 !important;
                                        }
        </style></div>
        
        `;  
       document.getElementById("member-resources").appendChild(li);  
    
       
    
    
    
    
        
       }
    
    
    
        }).catch((error) => {
         
    
    
            var li = document.createElement("div");  
            li.innerHTML = `
       

       
            <hr>
            <center> <h3>Looks Like You Lost Connection To Internet . </h3></center>
            <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" rel="stylesheet"><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
            <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" rel="stylesheet">
            <style type="text/css">.heading {
                                                font-family: 'Fjalla One', sans-serif;
                                                color: #331818;
                                                margin: 1em auto;
                                            }
                                            
                                            #response_message .bg-success,
                                            .bg-danger {
                                                background: black !important;
                                                color: white !important;
                                            }
                                            
                                            .btn btn-primary {
                                                color: white !important;
                                                font-weight: 700 !important;
                                            }
            </style>
            <style type="text/css">body {
                                                background: transparent;
                                            }
                                            
                                            .heading {
                                                font-family: 'Fjalla One', sans-serif;
                                                color: #331818;
                                                margin: 1em auto;
                                            }
                                            
                                            #response_message .btn {
                                                background: white !important;
                                                color: black !important;
                                                font-weight: 700 !important;
                                            }
            </style></div>
            
            `;  
           document.getElementById("member-resources").appendChild(li);  
        
           
    
           
    
    
    
            });
    
    
    
    
    
    
    })
   